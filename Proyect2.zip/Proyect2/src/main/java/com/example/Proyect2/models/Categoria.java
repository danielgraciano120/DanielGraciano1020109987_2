package com.example.Proyect2.models;

public enum Categoria {
    REDES, SOFTWARE, HARDWARE, SOPORTE
}