package com.example.Proyect2.models;

public enum Empresa {
    AMAZON, GOOGLE, MICROSOFT, IBM, DELL, HP, ORACLE
}
